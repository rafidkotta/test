Themes are used to configure the look and feel of login pages and the account management console. It is not recommended to
modify the existing built-in themes, instead you should create a new theme that extends a built-in theme. See the theme
section in the documentation for more details.